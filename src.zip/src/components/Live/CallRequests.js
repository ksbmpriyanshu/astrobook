import { View, Text } from 'react-native'
import React from 'react'

const CallRequests = ({}) => {
  return (
    <View>
      <Text allowFontScaling={false}>CallRequests</Text>
    </View>
  )
}

export default CallRequests