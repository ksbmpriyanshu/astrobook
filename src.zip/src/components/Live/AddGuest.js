import { View, Text } from 'react-native'
import React from 'react'

const AddGuest = ({}) => {
  return (
    <View>
      <Text allowFontScaling={false}>AddGuest</Text>
    </View>
  )
}

export default AddGuest