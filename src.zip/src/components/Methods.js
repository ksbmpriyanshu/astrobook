import { Linking } from "react-native";
import { warnign_toast } from "./MyToastMessage";

export const openInstagram = () => {
    warnign_toast('Coming Soon...');
    // const phoneNumber = '+916371133825'; // Replace with the desired phone number
    // const text = 'Hello AstroKing\nI need some help.'; // Replace with the desired pre-filled text

    // const url = `https://instagram.com/astrokingtech?igshid=ZDdkNTZiNTM=`;

    // Linking.canOpenURL(url)
    //   .then(supported => {
    //     if (supported) {
    //       return Linking.openURL(url);
    //     } else {
    //       console.log('Instagram is not installed on this device');
    //     }
    //   })
    //   .catch(error => console.log(error));
  };

export const openFacebook = () => {
  warnign_toast('Coming Soon...');
    // const phoneNumber = '+916371133825'; // Replace with the desired phone number
    // const text = 'Hello AstroKing\nI need some help.'; // Replace with the desired pre-filled text

    // const url = `https://www.facebook.com/profile.php?id=100091004506248&mibextid=ZbWKwL`;

    // Linking.canOpenURL(url)
    //   .then(supported => {
    //     if (supported) {
    //       return Linking.openURL(url);
    //     } else {
    //       console.log('Facebook is not installed on this device');
    //     }
    //   })
    //   .catch(error => console.log(error));
  };

 export const openYoutube = () => {
  warnign_toast('Coming Soon...');
    // const phoneNumber = '+916371133825'; // Replace with the desired phone number
    // const text = 'Hello AstroKing\nI need some help.'; // Replace with the desired pre-filled text

    // const url = `https://youtube.com/@astroking9`;

    // Linking.canOpenURL(url)
    //   .then(supported => {
    //     if (supported) {
    //       return Linking.openURL(url);
    //     } else {
    //       console.log('Youtube is not installed on this device');
    //     }
    //   })
    //   .catch(error => console.log(error));
  };

  export const openLinkedIn = () => {
    warnign_toast('Coming Soon...');
    // const phoneNumber = '+916371133825'; // Replace with the desired phone number
    // const text = 'Hello AstroKing\nI need some help.'; // Replace with the desired pre-filled text

    // const url = `https://youtube.com/@astroking9`;

    // Linking.canOpenURL(url)
    //   .then(supported => {
    //     if (supported) {
    //       return Linking.openURL(url);
    //     } else {
    //       console.log('LinkedIn is not installed on this device');
    //     }
    //   })
    //   .catch(error => console.log(error));
  };