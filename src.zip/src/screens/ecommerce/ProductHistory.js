import { View, Text } from 'react-native'
import React from 'react'

const ProductHistory = () => {
  return (
    <View>
      <Text>ProductHistory</Text>
    </View>
  )
}

export default ProductHistory