import { View, Text } from 'react-native'
import React from 'react'

const Consult = () => {
  return (
    <View>
      <Text allowFontScaling={false}>Consult</Text>
    </View>
  )
}

export default Consult