import { View, Text } from 'react-native'
import React from 'react'

const Article = () => {
  return (
    <View>
      <Text allowFontScaling={false}>Article</Text>
    </View>
  )
}

export default Article