import { View, Text } from 'react-native'
import React from 'react'

const Services = () => {
  return (
    <View>
      <Text allowFontScaling={false}>Services</Text>
    </View>
  )
}

export default Services