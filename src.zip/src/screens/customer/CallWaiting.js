import { View, Text } from 'react-native'
import React from 'react'

const CallWaiting = (props) => {
  return (
    <View>
      <Text allowFontScaling={false}>CallWaiting</Text>
    </View>
  )
}

export default CallWaiting