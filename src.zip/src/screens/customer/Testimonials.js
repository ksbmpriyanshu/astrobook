import { View, Text } from 'react-native'
import React from 'react'

const Testimonials = (props) => {
  return (
    <View>
      <Text allowFontScaling={false}>Testimonials</Text>
    </View>
  )
}

export default Testimonials