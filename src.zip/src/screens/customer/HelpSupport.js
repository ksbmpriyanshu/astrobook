import { View, Text } from 'react-native'
import React from 'react'

const HelpSupport = (props) => {
  return (
    <View>
      <Text allowFontScaling={false}>HelpSupport</Text>
    </View>
  )
}

export default HelpSupport