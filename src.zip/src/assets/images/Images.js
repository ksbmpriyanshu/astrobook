export const mainlogo = require('../images/AstroRemedyLogoN.png')
